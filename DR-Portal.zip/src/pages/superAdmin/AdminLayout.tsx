import DashboardLayout from "../../components/SideBarLayout";
export const SuperAdminLayout = () => {
  return <DashboardLayout role="SuperAdmin" />;
};
