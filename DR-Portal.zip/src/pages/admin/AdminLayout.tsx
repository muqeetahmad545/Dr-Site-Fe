import SideBarLayout from "../../components/SideBarLayout";
export const AdminLayout = () => {
  return <SideBarLayout role="admin" />;
};
