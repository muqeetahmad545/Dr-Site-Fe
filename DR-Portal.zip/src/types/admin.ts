export interface Admin {
  id: string;
  first_name?: string;
  last_name?: string;
  email: string;
  phone?: string;
  status?: string;
  address?: string;
}
