import SideBarLayout from "../../components/SideBarLayout";

const PatientLayout = () => {
  return <SideBarLayout role="patient" />;
};

export default PatientLayout;
