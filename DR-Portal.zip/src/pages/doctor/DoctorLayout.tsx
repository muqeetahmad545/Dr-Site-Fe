import SideBarLayout from "../../components/SideBarLayout";

const DoctorLayout = () => {
  return <SideBarLayout role="doctor" />;
};

export default DoctorLayout;
